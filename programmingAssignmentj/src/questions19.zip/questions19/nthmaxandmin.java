package questions19;

public class nthmaxandmin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array= {23,1,2,34,22,678};

	}

}

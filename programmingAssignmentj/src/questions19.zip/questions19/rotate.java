package questions19;

public class rotate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {2,4,1,5,3,2};
		int rotate=2;
		rotate=rotate%arr.length;
		for(int i=0;i<arr.length;i++)
		{
			if(i<rotate)
			{
				System.out.print(arr[arr.length+i-rotate]+" ");
			}
			else {
				System.out.print(arr[i-rotate]+" ");
			}
		}

	}

}

package programmingAssignment;
public class duplicatechar25 {
	static String unichar(String text)
	{
		String temp = "";
		
		for(int i=0;i<text.length();i++)
		{
			boolean flag = true;
			for(int j=i+1;j<text.length();j++)
			{
				if(text.charAt(i)==text.charAt(j))
				{
					flag = false;
					break;
				}
			}
			if(flag)
			{
				temp = temp+text.charAt(i);
			}
		}
		return temp;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "java language";//jv.....//java -----jva
		System.out.println(unichar(str));
	}
}

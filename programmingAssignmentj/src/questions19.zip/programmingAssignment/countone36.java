package programmingAssignment;

public class countone36 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "One-one was a race horse.Two-two was one too.One-one won one race.Two-two won one too";
		String[] str1 = str.split(" ")

	}

}
